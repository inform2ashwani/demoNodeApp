# node-file-upload-api

[Create Node Express & Multer File Upload & Download REST API](https://www.remotestack.io/create-node-express-multer-file-upload-download-rest-api/)